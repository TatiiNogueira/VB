﻿Module Module1

    Sub Main()
        'Mostrar mensagem
        Console.WriteLine("Bienvenidos al curso de VB")
        'A janela só irá fechar quando clicarmos numa tecla qualquer
        Console.ReadKey(True)
    End Sub

End Module
