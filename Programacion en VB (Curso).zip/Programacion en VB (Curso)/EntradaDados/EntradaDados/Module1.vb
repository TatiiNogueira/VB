﻿Module Module1

    Sub Main()
        Console.Write("Indique o seu nome: ")
        Dim MiNombre As String = Console.ReadLine()
        Console.WriteLine("Bem vindo " & MiNombre)
        Console.ReadKey(True)
    End Sub

End Module
