﻿Module Module1

    Sub Main()
        Dim aritmetico As Double = 8 + 3
        Dim Number As Double = 10

        Number += 5

        Console.WriteLine(aritmetico)
        Console.WriteLine(Number)
        Console.ReadKey(True)
    End Sub

End Module
