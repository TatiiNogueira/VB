﻿Module Module1

    Sub Main()
        'Variavéis
        'Dim é o que permite criar uma varivel
        'Atribuimos um nome à nossa variavel
        'A seguir a "As" colocamo o tipo de dado que queremos
        'Colocamos igual e ao dado que queremos
        Dim numero As Integer = 12
        'Ou podemos fazer 
        Dim Number As Integer
        Number = 15

        'Constantes
        Const Pulgada As Double = 3.5

    End Sub

End Module
