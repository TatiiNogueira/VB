﻿Module Module1

    'Programa qque imprime os primeiros 20 números da seguinte série
    '1,3,6,10,15,21,28,.....

    Sub Main()

        'Declaração das Variáveis
        Dim Soma As Integer = 1

        'Loop
        'i é onde inicia a contagem
        'Limite 
        'Indicação de quantas em quantas casas vai andar
        For i = 1 To 3 Step 1
            Console.WriteLine("O melhor curso de VB")
        Next

        For i = 2 To 20 Step 1
            If i <> 20 Then
                Console.Write(Soma & ",")
            Else
                Console.WriteLine(Soma)
            End If
            Soma = Soma + i
        Next

        Console.ReadKey(True)
    End Sub

End Module
