﻿Module Module1

    'Realizar um programa que mostre na consola se um estudante tem dinheiro suficiente paa estudar
    'O valor do curso é de 600€
    'Se o estudante tiver dinheiro para estudar o programa irá mostrar quanto dinherio lhe sobra
    'Se o estudante não tiver dinherio suficiente para estudar o programa mostra quanto dinheiro falta

    Sub Main()
        'Declarar as variáveis
        Dim Estudia As Boolean = False
        Dim Falta As Double

        Console.Write("Indique a quantidade de dinheiro que tem: ")
        'Input
        Dim DineroAhorrado As Double = Console.ReadLine()

        If DineroAhorrado >= 600 Then
            Estudia = True
        End If

        If Estudia = True Then
            Falta = DineroAhorrado - 600
            Console.WriteLine("Tem dinheiro suficiente para estudar")
            Console.WriteLine("E ainda sobra " & Falta & " Euros")
        Else
            Console.WriteLine("O dinheiro não é suficiente para estudar")
            Falta = 600 - DineroAhorrado
            Console.WriteLine("Falta " & Falta & " Euros")
        End If

        Console.ReadKey(True)
    End Sub

End Module
