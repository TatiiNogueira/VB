﻿Module Module1

    Dim numero As Integer = 12

    Sub Main()
        numero = 24
    End Sub

    Sub OtroMetodo()
        numero = 80
    End Sub
End Module
