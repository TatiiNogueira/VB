﻿Module Module1

    Sub Main()
        Dim numero As Integer

        'Inicio do Loop
        Do
            Console.Write("Introduza um número: ")
            'Obter o número introduzido
            numero = Console.ReadLine()
            Console.WriteLine("Este é o melhor curso de VB")

            'Fim do Loop - Indicação quando o loop irá terminar
            'Neste caso o lopp termina se o número indicado for diferente de zero
        Loop Until numero <> 0
    End Sub

End Module
