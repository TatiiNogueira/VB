﻿Module Module1

    'Programa que lê um número N inteiro positivo de qualquer número de digitos,
    'Calcula a soma dos seus digitos e imprime na consola o núemro lido e a soma dos seus digitos
    'EXEMPLOS: N = 89563       SOMA = 31

    Sub Main()

    End Sub

End Module
