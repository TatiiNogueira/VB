﻿Module Module1

    'Programa que permite realizar uma operação matemática entre dois núemros
    '1.Soma
    '2.Menos
    '3.Multiplicação
    '4.Divisão
    '5.Percentagem

    Sub Main()
        Console.WriteLine("As operações são:")
        Console.WriteLine("
    1.Soma
    2.Menos
    3.Multiplicação
    4.Divisão
    5.Percentagem")
        Console.Write("Indique o número da operação que deseja executar: ")
        'Input
        Dim Opcao As Integer = Console.ReadLine()

        'Indica das Variáveis
        Dim numero1, numero2 As Double

        Console.Write("Indique o primeiro número -> ")
        numero1 = Console.ReadLine()
        Console.Write("Indique o segundo número -> ")
        numero2 = Console.ReadLine()

        Select Case Opcao
            Case 1
                Console.WriteLine("O resultado da Soma é " & numero1 + numero2)
            Case 2
                Console.WriteLine("O resultado da Subdtração é " & numero1 - numero2)
            Case 3
                Console.WriteLine("O resultado da Multiplicação é " & numero1 * numero2)
            Case 4
                Console.WriteLine("O resultado da Divisão é " & numero1 / numero2)
            Case 5
                Console.WriteLine("O " & numero2 & "% de " & numero1 & " é " & (numero1 * numero2) / 100)
        End Select

        Console.ReadKey(True)
    End Sub

End Module
