﻿'Link do Video - Generate Barcode (Código de Barras) -> https://www.youtube.com/watch?v=MOA2rJZ3EcU
'Link do Video - Generate QRCode -> https://www.youtube.com/watch?v=MFAkgEnCx8I

'Importações
Imports QRCoder
Imports ZXing

Public Class Form1

    'Button Gerar QRCode
    Private Sub btnQRCode_Click(sender As Object, e As EventArgs) Handles btnQRCode.Click
        Dim gen As New QRCodeGenerator
        'Converte o texto para QRCode
        Dim data = gen.CreateQrCode(txtQRCode.Text, QRCodeGenerator.ECCLevel.Q)
        Dim code As New QRCode(data)
        'Gera o QRCode
        pic.Image = code.GetGraphic(5)
    End Sub

    'Button Gerar Código de Barras
    Private Sub btnCodigoBarras_Click(sender As Object, e As EventArgs) Handles btnCodigoBarras.Click
        Dim writter As New BarcodeWriter
        'Faz a conversão de números pra o código de barras
        writter.Format = BarcodeFormat.CODE_128
        'Indicação de queremos que apareça o código de barras na PictureBox (pic)
        pic.Image = writter.Write(txtBarcore.Text)
    End Sub
End Class
