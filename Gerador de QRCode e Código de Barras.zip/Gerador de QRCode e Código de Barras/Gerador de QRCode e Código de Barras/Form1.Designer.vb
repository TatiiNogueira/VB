﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBarcore = New System.Windows.Forms.TextBox()
        Me.btnCodigoBarras = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pic = New System.Windows.Forms.PictureBox()
        Me.txtQRCode = New System.Windows.Forms.TextBox()
        Me.btnQRCode = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.pic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtBarcore
        '
        Me.txtBarcore.BackColor = System.Drawing.Color.Tomato
        Me.txtBarcore.Location = New System.Drawing.Point(152, 211)
        Me.txtBarcore.Name = "txtBarcore"
        Me.txtBarcore.Size = New System.Drawing.Size(254, 20)
        Me.txtBarcore.TabIndex = 11
        '
        'btnCodigoBarras
        '
        Me.btnCodigoBarras.BackColor = System.Drawing.Color.Tomato
        Me.btnCodigoBarras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCodigoBarras.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCodigoBarras.Location = New System.Drawing.Point(412, 209)
        Me.btnCodigoBarras.Name = "btnCodigoBarras"
        Me.btnCodigoBarras.Size = New System.Drawing.Size(158, 23)
        Me.btnCodigoBarras.TabIndex = 10
        Me.btnCodigoBarras.Text = "Gerar Código de Barras"
        Me.btnCodigoBarras.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS Mincho", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 216)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 11)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Insira  o Barcore:"
        '
        'pic
        '
        Me.pic.BackColor = System.Drawing.Color.Tomato
        Me.pic.Location = New System.Drawing.Point(19, 12)
        Me.pic.Name = "pic"
        Me.pic.Size = New System.Drawing.Size(551, 174)
        Me.pic.TabIndex = 8
        Me.pic.TabStop = False
        '
        'txtQRCode
        '
        Me.txtQRCode.BackColor = System.Drawing.Color.Tomato
        Me.txtQRCode.Location = New System.Drawing.Point(152, 256)
        Me.txtQRCode.Multiline = True
        Me.txtQRCode.Name = "txtQRCode"
        Me.txtQRCode.Size = New System.Drawing.Size(254, 80)
        Me.txtQRCode.TabIndex = 15
        '
        'btnQRCode
        '
        Me.btnQRCode.BackColor = System.Drawing.Color.Tomato
        Me.btnQRCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQRCode.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnQRCode.Location = New System.Drawing.Point(412, 313)
        Me.btnQRCode.Name = "btnQRCode"
        Me.btnQRCode.Size = New System.Drawing.Size(158, 23)
        Me.btnQRCode.TabIndex = 14
        Me.btnQRCode.Text = "Gerar QRCode"
        Me.btnQRCode.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS Mincho", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(17, 256)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 11)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Insira  Texto:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(582, 342)
        Me.Controls.Add(Me.txtQRCode)
        Me.Controls.Add(Me.btnQRCode)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtBarcore)
        Me.Controls.Add(Me.btnCodigoBarras)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pic)
        Me.Name = "Form1"
        Me.Text = "Gerador de QRCode e Código de Barras"
        CType(Me.pic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtBarcore As TextBox
    Friend WithEvents btnCodigoBarras As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents pic As PictureBox
    Friend WithEvents txtQRCode As TextBox
    Friend WithEvents btnQRCode As Button
    Friend WithEvents Label2 As Label
End Class
